api_base = "http://localhost:5001";

(function () {
  const launcher = document.getElementById('chat-launcher');
  const popup = document.getElementById('chat-popup');
  const closeBtn = document.getElementById('chat-close');
  const messagesEl = document.getElementById('chat-messages');

  const form = document.getElementById('chat-form');
  const textInput = document.getElementById('chat-text');
  const fileInput = document.getElementById('chat-file');
  const fileHint = document.getElementById('chat-file-hint');

  const allowedExt = ['png', 'jpg', 'jpeg', 'pdf'];

  function getOrCreateUserIdentifier() {
    const key = 'chat_user_identifier';
    const existing = localStorage.getItem(key);
    if (existing) return existing;

    const rand = Math.floor(100000 + Math.random() * 900000);
    const id = `USER${rand}`;
    localStorage.setItem(key, id);
    return id;
  }

  const userIdentifier = getOrCreateUserIdentifier();
  let lastId = 0;
  let pollTimer = null;

  function togglePopup(open) {
    if (open) {
      popup.classList.remove('hidden');
      launcher.classList.add('hidden');
      textInput.focus();
      startPolling();
    } else {
      popup.classList.add('hidden');
      launcher.classList.remove('hidden');
      stopPolling();
    }
  }

  launcher.addEventListener('click', function () {
    togglePopup(true);
  });

  closeBtn.addEventListener('click', function () {
    togglePopup(false);
  });

  function escapeHtml(s) {
    return (s || '')
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#039;');
  }

  function renderMessage(msg) {
    const row = document.createElement('div');
    row.className = 'chat-row ' + (msg.sender === 'user' ? 'from-user' : 'from-admin');

    const bubble = document.createElement('div');
    bubble.className = 'chat-bubble';

    const meta = document.createElement('div');
    meta.className = 'chat-meta';

    if (msg.sender === 'admin') {
      meta.textContent = (msg.admin_name && msg.admin_name.trim()) ? `admin • ${msg.admin_name}` : 'admin';
    } else {
      meta.textContent = 'you';
    }

    const body = document.createElement('div');
    body.className = 'chat-body';
    body.innerHTML = escapeHtml(msg.message);

    bubble.appendChild(meta);
    bubble.appendChild(body);

    if (msg.has_file) {
      const a = document.createElement('a');
      a.className = 'chat-attachment';
      a.href = `${api_base}/api/messages/${msg.id}/file?user_identifier=${encodeURIComponent(userIdentifier)}`;
      a.target = '_blank';
      a.rel = 'noopener noreferrer';
      a.textContent = 'Download attachment';
      bubble.appendChild(a);
    }

    row.appendChild(bubble);
    messagesEl.appendChild(row);
  }

  function scrollToBottom() {
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  async function pollOnce() {
    const url = `${api_base}/api/messages?user_identifier=${encodeURIComponent(userIdentifier)}&after_id=${encodeURIComponent(String(lastId))}`;

    const res = await fetch(url, { method: 'GET' });
    if (!res.ok) return;

    const data = await res.json();
    const msgs = data.messages || [];

    if (msgs.length > 0) {
      msgs.forEach(renderMessage);
      lastId = data.last_id || lastId;
      scrollToBottom();
    }
  }

  function startPolling() {
    if (pollTimer) return;
    pollOnce();
    pollTimer = setInterval(pollOnce, 1000);
  }

  function stopPolling() {
    if (!pollTimer) return;
    clearInterval(pollTimer);
    pollTimer = null;
  }

  function validateFile(file) {
    if (!file) return null;
    const name = file.name || '';
    const ext = name.includes('.') ? name.split('.').pop().toLowerCase() : '';
    if (!allowedExt.includes(ext)) return 'Only .png, .jpg, .jpeg, .pdf files are allowed.';
    return null;
  }

  fileInput.addEventListener('change', function () {
    const f = fileInput.files && fileInput.files[0];
    if (!f) {
      fileHint.textContent = '';
      return;
    }

    const err = validateFile(f);
    if (err) {
      fileHint.textContent = err;
      fileInput.value = '';
      return;
    }

    fileHint.textContent = `Attached: ${f.name}`;
  });

  form.addEventListener('submit', async function (e) {
    e.preventDefault();

    const text = (textInput.value || '').trim();
    const file = fileInput.files && fileInput.files[0];

    const err = validateFile(file);
    if (err) {
      fileHint.textContent = err;
      return;
    }

    if (!text && !file) return;

    const fd = new FormData();
    fd.append('user_identifier', userIdentifier);
    fd.append('message', text);
    if (file) fd.append('file', file, file.name);

    const res = await fetch(`${api_base}/api/messages`, {
      method: 'POST',
      body: fd,
    });

    if (!res.ok) {
      return;
    }

    textInput.value = '';
    fileInput.value = '';
    fileHint.textContent = '';

    await pollOnce();
  });
})();
